#!/bin/bash
# Romona Setup Script for macOS / Linux
# Usage: chmod +x scripts/setup.sh && ./scripts/setup.sh

set -e

echo ""
echo "========================================"
echo "   Bringing Romona to life...           "
echo "========================================"
echo ""

# ------------------------------------------
# Step 1: Check/Install Ollama
# ------------------------------------------
echo "[1/5] Checking Ollama..."

if command -v ollama &> /dev/null; then
    echo "  ✓ Ollama is already installed."
else
    echo "  Installing Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
fi

# ------------------------------------------
# Step 2: Start Ollama service
# ------------------------------------------
echo "[2/5] Starting Ollama service..."

if pgrep -x "ollama" > /dev/null; then
    echo "  ✓ Ollama is already running."
else
    ollama serve &
    sleep 3
    echo "  ✓ Ollama service started."
fi

# ------------------------------------------
# Step 3: Pull base model
# ------------------------------------------
echo "[3/5] Pulling Gemma 3 12B model (this may take a while on first run)..."
ollama pull gemma3:12b || {
    echo "  ⚠ Failed to pull gemma3:12b. Trying smaller model..."
    ollama pull gemma3:4b
    sed -i.bak 's/FROM gemma3:12b/FROM gemma3:4b/' modelfile/Romona.modelfile
    echo "  ✓ Fell back to gemma3:4b."
}
echo "  ✓ Model downloaded."

# ------------------------------------------
# Step 4: Create Romona personality
# ------------------------------------------
echo "[4/5] Creating Romona's personality..."
ollama create romona -f modelfile/Romona.modelfile && echo "  ✓ Romona is ready." || echo "  ⚠ Could not create custom model."

# ------------------------------------------
# Step 5: Check/Install Open WebUI
# ------------------------------------------
echo "[5/5] Setting up Open WebUI..."

if command -v open-webui &> /dev/null; then
    echo "  ✓ Open WebUI is already installed."
else
    echo "  Installing Open WebUI via pip..."
    pip install open-webui --break-system-packages 2>/dev/null || pip install open-webui
fi

# ------------------------------------------
# Done!
# ------------------------------------------
echo ""
echo "========================================"
echo "   Romona is alive!                     "
echo "========================================"
echo ""
echo "Open your browser to: http://localhost:8080"
echo "Select model 'romona' from the dropdown."
echo ""
echo "To stop: press Ctrl+C"
echo ""

open-webui serve --port 8080
