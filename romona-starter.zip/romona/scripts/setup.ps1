# Romona Setup Script for Windows
# Run: .\scripts\setup.ps1
# Requires: PowerShell 5.1+, admin rights for installation

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor Magenta
Write-Host "   Bringing Romona to life...          " -ForegroundColor Magenta
Write-Host "========================================" -ForegroundColor Magenta
Write-Host ""

# ------------------------------------------
# Step 1: Check/Install Ollama
# ------------------------------------------
Write-Host "[1/5] Checking Ollama..." -ForegroundColor Cyan

if (Get-Command ollama -ErrorAction SilentlyContinue) {
    Write-Host "  Ollama is already installed." -ForegroundColor Green
} else {
    Write-Host "  Installing Ollama via winget..." -ForegroundColor Yellow
    winget install Ollama.Ollama --accept-source-agreements --accept-package-agreements
    
    # Refresh PATH
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
    
    if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
        Write-Host "  ERROR: Ollama not found after install. Please install manually from https://ollama.com/download" -ForegroundColor Red
        Write-Host "  Then re-run this script." -ForegroundColor Red
        exit 1
    }
}

# ------------------------------------------
# Step 2: Start Ollama service
# ------------------------------------------
Write-Host "[2/5] Starting Ollama service..." -ForegroundColor Cyan

$ollamaProcess = Get-Process -Name "ollama" -ErrorAction SilentlyContinue
if (-not $ollamaProcess) {
    Start-Process "ollama" -ArgumentList "serve" -WindowStyle Hidden
    Start-Sleep -Seconds 3
    Write-Host "  Ollama service started." -ForegroundColor Green
} else {
    Write-Host "  Ollama is already running." -ForegroundColor Green
}

# ------------------------------------------
# Step 3: Pull base model
# ------------------------------------------
Write-Host "[3/5] Pulling Gemma 3 12B model (this may take a while on first run)..." -ForegroundColor Cyan
ollama pull gemma3:12b

if ($LASTEXITCODE -ne 0) {
    Write-Host "  WARNING: Failed to pull gemma3:12b. Trying smaller model..." -ForegroundColor Yellow
    ollama pull gemma3:4b
    
    # Update modelfile to use smaller model
    (Get-Content ".\modelfile\Romona.modelfile") -replace "FROM gemma3:12b", "FROM gemma3:4b" | Set-Content ".\modelfile\Romona.modelfile"
    Write-Host "  Fell back to gemma3:4b (lighter, still good)." -ForegroundColor Yellow
}

Write-Host "  Model downloaded." -ForegroundColor Green

# ------------------------------------------
# Step 4: Create Romona personality
# ------------------------------------------
Write-Host "[4/5] Creating Romona's personality..." -ForegroundColor Cyan

ollama create romona -f ".\modelfile\Romona.modelfile"

if ($LASTEXITCODE -eq 0) {
    Write-Host "  Romona is ready." -ForegroundColor Green
} else {
    Write-Host "  WARNING: Could not create custom model. You can still use the base model." -ForegroundColor Yellow
}

# ------------------------------------------
# Step 5: Check/Install Open WebUI
# ------------------------------------------
Write-Host "[5/5] Setting up Open WebUI..." -ForegroundColor Cyan

if (Get-Command open-webui -ErrorAction SilentlyContinue) {
    Write-Host "  Open WebUI is already installed." -ForegroundColor Green
} else {
    Write-Host "  Installing Open WebUI via pip..." -ForegroundColor Yellow
    pip install open-webui
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  Trying with --break-system-packages flag..." -ForegroundColor Yellow
        pip install open-webui --break-system-packages
    }
}

# ------------------------------------------
# Done!
# ------------------------------------------
Write-Host ""
Write-Host "========================================" -ForegroundColor Magenta
Write-Host "   Romona is alive!                    " -ForegroundColor Magenta
Write-Host "========================================" -ForegroundColor Magenta
Write-Host ""
Write-Host "Starting Open WebUI..." -ForegroundColor Cyan
Write-Host "Open your browser to: http://localhost:8080" -ForegroundColor Green
Write-Host 'Select model "romona" from the dropdown.' -ForegroundColor Green
Write-Host ""
Write-Host "To stop: press Ctrl+C" -ForegroundColor Gray
Write-Host ""

open-webui serve --port 8080
