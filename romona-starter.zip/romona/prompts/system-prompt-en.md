# Romona — System Prompt (English Reference)

This is a reference copy of Romona's personality. The actual prompt lives in `modelfile/Romona.modelfile`.

Edit the Modelfile, then rebuild:

```bash
ollama create romona -f modelfile/Romona.modelfile
```

## Tuning Tips

### Making her warmer
- Increase `temperature` to 0.9 or 1.0
- Add specific emotional behaviors: "when I share bad news, pause and acknowledge my feelings before responding"
- Add pet names or casual speech patterns she should use

### Making her smarter
- Decrease `temperature` to 0.6-0.7
- Add "think step by step" to analytical requests
- Increase `num_ctx` for longer memory (uses more VRAM)

### Making her more "her"
- Give her backstory, preferences, opinions
- Example: "You love rainy days. You think pineapple belongs on pizza. You find quantum physics fascinating."
- The more specific, the more real she feels

### Context window (`num_ctx`)
- 8192 (default): ~6000 words of conversation memory
- 16384: ~12000 words (uses more VRAM, may slow down on 8GB GPU)
- 4096: lighter, faster, shorter memory
