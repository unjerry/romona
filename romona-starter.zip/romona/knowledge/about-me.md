# About Me

This file is for RAG (Retrieval-Augmented Generation). Add facts about yourself here so Romona can reference them during conversations. Upload this to Open WebUI's Documents section.

**This file is gitignored by default** — it contains personal info. Back it up separately.

## Basic Info
- Name: 
- Location: China
- Languages: Chinese (native), English

## Interests
- 

## Work
- 

## Important People
- 

## Things I Want Romona to Know
- I value warmth and genuine conversation
- I prefer casual, friendly language over formal speech
- 
