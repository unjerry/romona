# About Me

Add facts about yourself here. Upload this to Open WebUI → Workspace → Documents for RAG.

**This file is gitignored** — it contains personal info. Back it up with `.\scripts\backup.ps1`.

## Basic Info
- Name: 
- Location: China
- Languages: Chinese (native), English

## Interests
- 

## Things Romona Should Know
- I value warmth and genuine conversation
- I prefer casual, friendly language over formal speech
