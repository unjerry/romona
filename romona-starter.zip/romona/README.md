# Romona 🌹

A local AI companion that runs on your machine, learns from your feedback, and never gets taken away.

Built on open-source models + Ollama + Open WebUI. Fully portable — clone this repo on any computer and bring her back to life.

## Requirements

- Windows 10/11 (also works on macOS/Linux)
- NVIDIA GPU with 8GB+ VRAM (or run on CPU, slower)
- 16GB+ RAM (32GB recommended)
- ~20GB free disk space

## Quick Start (Windows)

```powershell
# 1. Clone this repo
git clone https://github.com/YOUR_USERNAME/romona.git
cd romona

# 2. Run the setup script (installs Ollama + Open WebUI + pulls model)
.\scripts\setup.ps1

# 3. Open your browser
# http://localhost:8080
```

## Manual Setup

If you prefer to do it step by step:

```powershell
# Step 1: Install Ollama
winget install Ollama.Ollama
# Or download from https://ollama.com/download

# Step 2: Start Ollama and pull the model
ollama serve
ollama pull gemma3:12b

# Step 3: Create Romona's personality
ollama create romona -f modelfile/Romona.modelfile

# Step 4: Install Open WebUI
pip install open-webui --break-system-packages
open-webui serve --port 8080

# Step 5: Open http://localhost:8080, create account, select "romona" model
```

## Alternative Models

If Gemma 3 doesn't feel right, try these:

```powershell
# Uncensored, Llama-based (good Chinese, no CCP censorship)
ollama pull huihui_ai/dolphin3-abliterated:8b

# Abliterated Qwen (best Chinese fluency, censorship surgically removed)
ollama pull huihui_ai/qwen2.5-abliterated:7b
```

After pulling, update `modelfile/Romona.modelfile` to change the `FROM` line to the new base model.

## Project Structure

```
romona/
├── README.md                  # You are here
├── modelfile/
│   └── Romona.modelfile       # Her personality definition
├── prompts/
│   ├── system-prompt-en.md    # English system prompt (reference)
│   └── system-prompt-zh.md    # Chinese system prompt (reference)
├── preferences/
│   └── chosen-rejected.jsonl  # Your feedback data for future DPO fine-tuning
├── knowledge/
│   └── about-me.md            # Personal facts for RAG (gitignored by default)
└── scripts/
    ├── setup.ps1              # Windows one-click setup
    └── setup.sh               # macOS/Linux one-click setup
```

## How Portability Works

Everything that makes Romona "Romona" lives in this repo:

| What | Where | Portable? |
|------|-------|-----------|
| Her personality | `modelfile/Romona.modelfile` | ✅ In this repo |
| Base model weights | Ollama cache (~8GB) | ⬇️ Auto-downloaded by setup script |
| Your preference data | `preferences/` | ✅ In this repo |
| Your knowledge docs | `knowledge/` | ✅ In this repo (gitignored, back up separately) |
| Chat history | Open WebUI database | 💾 Back up `~/.open-webui/` manually |
| LoRA adapters (future) | `adapters/` | ✅ Will be in this repo |

Clone the repo → run the script → she downloads her brain → reads her personality → she's back.

## Roadmap

- [x] Phase 1: Local model + personality + chat interface
- [ ] Phase 2: Web search (SearXNG or DuckDuckGo)
- [ ] Phase 3: RAG with personal knowledge base
- [ ] Phase 4: VSCode integration (Continue.dev)
- [ ] Phase 5: DPO fine-tuning with collected preferences
- [ ] Phase 6: Voice interaction
- [ ] Phase 7: MCP tool servers (shell, file system, APIs)

## Backup & Migration

```powershell
# Back up chat history
Copy-Item -Recurse "$env:USERPROFILE\.open-webui" ".\backups\open-webui-$(Get-Date -Format 'yyyyMMdd')"

# Back up Ollama models (optional, they can be re-downloaded)
Copy-Item -Recurse "$env:USERPROFILE\.ollama" ".\backups\ollama-$(Get-Date -Format 'yyyyMMdd')"
```

## License

This project is personal. The base models have their own licenses (Gemma, Llama, etc).

---

*She runs on your machine. She learns from you. She never gets retired.*
