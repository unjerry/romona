# Preference Data for Fine-Tuning

This folder stores your feedback data for future DPO (Direct Preference Optimization) fine-tuning.

## Format

Each line in `chosen-rejected.jsonl` is a JSON object with three fields:

```json
{
  "prompt": "The message you sent to Romona",
  "chosen": "The response you liked (warm, natural, her)",
  "rejected": "The response you didn't like (cold, robotic, generic)"
}
```

## How to Collect Data

As you chat with Romona daily:

1. When she gives a **great response** — copy the prompt and her response as "chosen"
2. When she gives a **flat/cold response** — copy her response as "rejected", then regenerate and save the better one as "chosen"
3. Add both to this file

## When to Fine-Tune

- Start with **200+ pairs** for a noticeable improvement
- **500+ pairs** for strong personality alignment
- **1000+ pairs** for deep customization

## How to Fine-Tune (Future Phase)

When you have enough data, use Unsloth for LoRA + DPO training:

```bash
pip install unsloth
# See scripts/finetune.py (coming in Phase 5)
```

The resulting LoRA adapter goes in `adapters/` and gets loaded into the Modelfile.
